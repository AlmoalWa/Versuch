<?php

namespace MRBS\Form;

class ElementImg extends Element
{
  
  public function __construct()
  {
    parent::__construct('img', true);
  }
 
}